# Code for the data-submission
Interactive code can be found in ```Twitter.ipynb```. Python code for submission via spark-submit can be found in rforest.py, which generates a model based on training data and outputs predictions for all 4 target classes. 

For formatting, format_pd.py was used. The code was run at the TU Vienna BigData hadoop cluster.